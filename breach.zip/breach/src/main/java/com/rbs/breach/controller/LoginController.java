/**
 * 
 */
package com.rbs.breach.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author user
 *
 */

@RestController
public class LoginController {
	
@RequestMapping("/")
	public void loginMethod()
	{
	
	}
}
