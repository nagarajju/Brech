/**
 * 
 */
package com.rbs.breach.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rbs.breach.beans.BreachBean;

/**
 * @author user
 *
 */

@Repository
public interface BreachDao extends JpaRepository<BreachBean, Integer>{
	
}
