package com.rbs.breach.service.impl;

import com.rbs.breach.beans.BreachBean;
import com.rbs.breach.service.BreachService;

public class BreachServiceImpl implements BreachService{

	@Override
	public BreachBean addBreach(BreachBean breach) {
		
		return null;
	}

}
