/**
 * 
 */
package com.rbs.breach.service;

import org.springframework.stereotype.Service;

import com.rbs.breach.beans.BreachBean;

/**
 * @author user
 *
 */
@Service
public interface BreachService {

	BreachBean addBreach(BreachBean breach);
	
}
