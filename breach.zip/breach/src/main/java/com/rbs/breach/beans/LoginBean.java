/**
 * 
 */
package com.rbs.breach.beans;

/**
 * @author user
 *
 */
public class LoginBean {

}
