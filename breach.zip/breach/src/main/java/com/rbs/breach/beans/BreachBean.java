package com.rbs.breach.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="breach_bean")
public class BreachBean {
	@Id
	@GeneratedValue
	private Integer id;
	private String franchaiseName;
	private String businessArea;
	private String identifiedBreach;
	
	
	
	public String getFranchaiseName() {
		return franchaiseName;
	}
	public void setFranchaiseName(String franchaiseName) {
		this.franchaiseName = franchaiseName;
	}
	public String getBusinessArea() {
		return businessArea;
	}
	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}
	public String getIdentifiedBreach() {
		return identifiedBreach;
	}
	public void setIdentifiedBreach(String identifiedBreach) {
		this.identifiedBreach = identifiedBreach;
	}
	
}
