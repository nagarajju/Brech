package com.rbs.breach.beans;

import javax.persistence.Entity;

import org.springframework.data.annotation.Id;

@Entity
public class BreachBean {
	@Id
	private Integer id;
	private String franchaiseName;
	private String businessArea;
	private String identifiedBreach;
	
	public String getFranchaiseName() {
		return franchaiseName;
	}
	public void setFranchaiseName(String franchaiseName) {
		this.franchaiseName = franchaiseName;
	}
	public String getBusinessArea() {
		return businessArea;
	}
	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}
	public String getIdentifiedBreach() {
		return identifiedBreach;
	}
	public void setIdentifiedBreach(String identifiedBreach) {
		this.identifiedBreach = identifiedBreach;
	}
	
}
