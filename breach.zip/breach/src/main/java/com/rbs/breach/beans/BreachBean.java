package com.rbs.breach.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="breach_bean")
public class BreachBean {
	@Id
	@GeneratedValue
	private Integer id;
	private String franchaiseName;
	private String businessArea;
	private String breachIdentifier;
	private String employeeName;
	private String companyType;
	private String reportedUser;
	private String companyName;
	private Long userContactDetails;
	private Date breachIdentifiedDate;
	private Date breachHappendDate;
	private Boolean breachAware;
	private String whereAndWhenAwared;
	private String breachLevel;
	private Boolean informationDestroyed;
	private Boolean misplacedByColleague;
	private String descriptionOfBreach;
	private Boolean yourBusiness;
	private String breachCausedFranchaise;
	private String brechCausedBusinessArea;
	private String impactedAccount;
	private String customerName;
	private String typeOfDataCompromised;
	private String riskProfile;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFranchaiseName() {
		return franchaiseName;
	}
	public void setFranchaiseName(String franchaiseName) {
		this.franchaiseName = franchaiseName;
	}
	public String getBusinessArea() {
		return businessArea;
	}
	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}
	public String getBreachIdentifier() {
		return breachIdentifier;
	}
	public void setBreachIdentifier(String breachIdentifier) {
		this.breachIdentifier = breachIdentifier;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public String getReportedUser() {
		return reportedUser;
	}
	public void setReportedUser(String reportedUser) {
		this.reportedUser = reportedUser;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Long getUserContactDetails() {
		return userContactDetails;
	}
	public void setUserContactDetails(Long userContactDetails) {
		this.userContactDetails = userContactDetails;
	}
	public Date getBreachIdentifiedDate() {
		return breachIdentifiedDate;
	}
	public void setBreachIdentifiedDate(Date breachIdentifiedDate) {
		this.breachIdentifiedDate = breachIdentifiedDate;
	}
	public Date getBreachHappendDate() {
		return breachHappendDate;
	}
	public void setBreachHappendDate(Date breachHappendDate) {
		this.breachHappendDate = breachHappendDate;
	}
	public Boolean getBreachAware() {
		return breachAware;
	}
	public void setBreachAware(Boolean breachAware) {
		this.breachAware = breachAware;
	}
	public String getWhereAndWhenAwared() {
		return whereAndWhenAwared;
	}
	public void setWhereAndWhenAwared(String whereAndWhenAwared) {
		this.whereAndWhenAwared = whereAndWhenAwared;
	}
	public String getBreachLevel() {
		return breachLevel;
	}
	public void setBreachLevel(String breachLevel) {
		this.breachLevel = breachLevel;
	}
	public Boolean getInformationDestroyed() {
		return informationDestroyed;
	}
	public void setInformationDestroyed(Boolean informationDestroyed) {
		this.informationDestroyed = informationDestroyed;
	}
	public Boolean getMisplacedByColleague() {
		return misplacedByColleague;
	}
	public void setMisplacedByColleague(Boolean misplacedByColleague) {
		this.misplacedByColleague = misplacedByColleague;
	}
	public String getDescriptionOfBreach() {
		return descriptionOfBreach;
	}
	public void setDescriptionOfBreach(String descriptionOfBreach) {
		this.descriptionOfBreach = descriptionOfBreach;
	}
	public Boolean getYourBusiness() {
		return yourBusiness;
	}
	public void setYourBusiness(Boolean yourBusiness) {
		this.yourBusiness = yourBusiness;
	}
	public String getBreachCausedFranchaise() {
		return breachCausedFranchaise;
	}
	public void setBreachCausedFranchaise(String breachCausedFranchaise) {
		this.breachCausedFranchaise = breachCausedFranchaise;
	}
	public String getBrechCausedBusinessArea() {
		return brechCausedBusinessArea;
	}
	public void setBrechCausedBusinessArea(String brechCausedBusinessArea) {
		this.brechCausedBusinessArea = brechCausedBusinessArea;
	}
	public String getImpactedAccount() {
		return impactedAccount;
	}
	public void setImpactedAccount(String impactedAccount) {
		this.impactedAccount = impactedAccount;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getTypeOfDataCompromised() {
		return typeOfDataCompromised;
	}
	public void setTypeOfDataCompromised(String typeOfDataCompromised) {
		this.typeOfDataCompromised = typeOfDataCompromised;
	}
	public String getRiskProfile() {
		return riskProfile;
	}
	public void setRiskProfile(String riskProfile) {
		this.riskProfile = riskProfile;
	}
	
}
