/**
 * 
 */
package com.rbs.breach.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rbs.breach.beans.BreachBean;
import com.rbs.breach.dao.BreachDao;

/**
 * @author user
 *
 */
@RestController("breachController")
public class BreachController {
	@Autowired
	private BreachDao breachDao;

	@PostMapping("/addDataBreach")
	public void addDataBreach(@RequestBody BreachBean breachBean){
		breachDao.save(breachBean);
		
	}
	public void addAllDataBreach(@RequestBody List<BreachBean> breachBeans){
		breachDao.saveAll(breachBeans);
	}
		
	@GetMapping("/getDataBreach")
	public BreachBean getDataBreach(){
		return null;
	}
		
}
